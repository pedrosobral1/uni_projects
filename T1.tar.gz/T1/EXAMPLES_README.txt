============================================================
Abstract syntax trees (ASTs)
============================================================

EXAMPLES:

ex_ast1.c: Successful;
ex_ast2.c: Variable not initialized;
ex_ast3.c: Variable not accepted;
