#include <stdio.h>

int main() {
  int x;
  x=3+2;
  int y=2;
  int z;
  z=x;

  printf("%d",y);
  printf("%d",1+2);

  if ((0==0)&&(3==3)){
    printf("%d",x);
  }
  else {
    scanf("%d",&z);
  }
  while (0!=0){
    printf("%d",x);
  }
  if (0==0){
    printf("%d",z);
  }
}
